/*
 * Demonstration program using the NeXus ISIS Read Routine
 *
 *
 * Tested: 1) Visual C++ 5.0, Windows NT 4.0
 *
 *
 * D.W.Flannery and S.P.Cottrell
 *
 */

#include <stdio.h>
#include "napi.h"
#include "nexus_reader.h"


int main(int argc, char* argv[])

{

struct NXM_MUONIDF *muon_ptr;
int *histogram_ptr;
int i, j, histogram;
char nxfname[80];

/* read filename from keyboard */
fprintf(stderr, "%s", "Please enter nexus filename : ");
scanf("%s", nxfname);
printf("\nNexus filename is : %s\n", nxfname);

/* read NeXus file */
(void) NXMread(nxfname, &muon_ptr);

/* print contents of NeXus file */
printf("\n\nNeXus File Contents\n\n");
printf("Program name: %s\n", muon_ptr->run_program_name);
printf("Program version: %s\n", muon_ptr->run_program_version);
printf("Run number: %d\n", muon_ptr->run_number);
printf("Title: %s\n", muon_ptr->run_title);
printf("Notes: %s\n", muon_ptr->run_notes);
printf("Analysis: %s\n", muon_ptr->run_analysis);
printf("Start_time: %s\n", muon_ptr->run_start_time);
printf("Stop_time: %s\n", muon_ptr->run_stop_time); 
printf("Duration: %s\n", muon_ptr->run_duration);
printf("Switching States: %d\n", muon_ptr->run_switching_states);
/* NXuser */
printf("Username: %s\n", muon_ptr->user_name);
printf("Experiment number: %s\n", muon_ptr->user_experiment_number);
/* NXsample */
printf("Sample: %s\n", muon_ptr->sample_name);
printf("Temperature: %f %s\n", muon_ptr->sample_temperature, muon_ptr->sample_temperature_units);
printf("Magnetic field: %f %s\n", muon_ptr->sample_magnetic_field, muon_ptr->sample_magnetic_field_units);
printf("Shape: %s\n", muon_ptr->sample_shape);
printf("Magnetic field state: %s\n", muon_ptr->sample_magnetic_field_state);
if (muon_ptr->sample_magnetic_field_vector_available != 0)
{
	printf("Magnetic field vector: [%f, %f, %f]\n", muon_ptr->sample_magnetic_field_vector[0],
													muon_ptr->sample_magnetic_field_vector[1],
													muon_ptr->sample_magnetic_field_vector[2]);
	printf("Coordinate system: %s\n", muon_ptr->sample_magnetic_field_vector_coord);
}
else
	printf("Magnetic field vector not available\n");
printf("Sample environment: %s\n", muon_ptr->sample_environment);
/* NXinstrument */
printf("Instrument name: %s\n", muon_ptr->instrument_name);
/* NXdetector */
printf("Number of detectors: %d\n", muon_ptr->detector_number);
printf("Detector orientation: %s\n", muon_ptr->detector_orientation);
/* print detector angle information */
if (muon_ptr->detector_angles_available != 0)
{
	printf("Position of first detector: [%f, %f, %f]\n", muon_ptr->detector_angles[0],
														 muon_ptr->detector_angles[1],
														 muon_ptr->detector_angles[2]);
	printf("Coordinate system: %s\n", muon_ptr->detector_angles_coord);
	printf("Solid angle of 1st detector: %f\n", muon_ptr->detector_angles[3]);
}
else
	printf("Detector angles not available\n");
/* print detector deadtime information */
if (muon_ptr->detector_deadtimes_available != 0)
{
	printf("\nDeadtimes available (in %s) ...\n",muon_ptr->detector_deadtimes_units);
	for (i = 0; i < muon_ptr->detector_number; i++)
		printf("Deadtime of detector %d: %f\n", (i + 1), muon_ptr->detector_deadtimes[i]);
}
else
	printf("\nDeadtime information not available\n");

/* NXcollimator */
printf("Collimator type: %s\n", muon_ptr->collimator_type);
printf("Collimator aperture: %s\n", muon_ptr->collimator_aperture);
/* NXbeam */
printf("Events: %f %s\n", muon_ptr->beam_total_counts, muon_ptr->beam_total_counts_units);
printf("Frames: %d\n", muon_ptr->beam_frames);
printf("DAEreads: %d\n", muon_ptr->beam_daereads);
/* NXdata */
printf("Number of histograms: %d\n", muon_ptr->histogram_number);
printf("Time zero bin: %d\n", muon_ptr->histogram_t0_bin);
printf("Histogram length: %d\n", muon_ptr->histogram_length);
printf("First good bin: %d\n", muon_ptr->histogram_first_good_bin);
printf("Last good bin: %d\n", muon_ptr->histogram_last_good_bin);
printf("Histogram resolution: %f\n", muon_ptr->histogram_resolution);

/* print grouping information if available */
if (muon_ptr->histogram_grouping_available > 0)
{
	printf("\nFound %d histogram groups\n", muon_ptr->histogram_grouping_available);
	for (i = 1; i <= muon_ptr->histogram_grouping_available; i++)
	{
		printf("Group %d histograms: ", i);
		for (j = 0; j < muon_ptr->histogram_number; j++)
			if ((*(muon_ptr->histogram_grouping + j)) == i)
				printf("%d, ", (j + 1));
		printf("\n");
	}
}
/* print alpha values for paired groups if available */
if (muon_ptr->histogram_alpha_available > 0)
{
	printf("alpha defined for %d pairs\n", muon_ptr->histogram_alpha_available);
	for (i = 0; i < muon_ptr->histogram_alpha_available; i++)
		printf("alpha for group pair %d (groups %f and %f): %f\n", (i + 1),
																   *(muon_ptr->histogram_alpha + (i * 3)),
																   *(muon_ptr->histogram_alpha + (i * 3) + 1),
																   *(muon_ptr->histogram_alpha + (i * 3) + 2));
}

/* print User Information */
printf("\n");
for (i = 0; i < muon_ptr->user_uif_array_length; i++)
{
	printf("User Information %d:\n", i + 1);
	printf("   Data Name: %s\n", muon_ptr->user_uif_array[i].uif_element_name);
	printf("   Data Value: %s\n", muon_ptr->user_uif_array[i].uif_element_value);
}

/* demonstrate pointer manipulation of individual histograms ... print every 50th value in the 1st histogram with time stamp */

printf("\nHistogram information - (Raw Time, Corrected Time, Counts) (time in %s):\n", muon_ptr->histogram_corrected_time_units);
histogram = 0;			/* choose which histogram you want (starting at zero) */
histogram_ptr = &(muon_ptr->histogram_counts[histogram * muon_ptr->histogram_length]);	/* get the start of desired histogram */
for (i = 0; i < (muon_ptr->histogram_length); i+=50)		/* extract data */
{
	printf("(%f, %f, %d)\n", *(muon_ptr->histogram_raw_time + i),
							 *(muon_ptr->histogram_corrected_time + i),
							 *(histogram_ptr+=50));
}
printf("\n");

/* access logged information ... temperature */
if (muon_ptr->temperature_log_available > 0)
{
	printf("\nTemperature Log - Time (%s), Temperature (%s)\n", muon_ptr->temperature_log_time_units, muon_ptr->temperature_log_values_units);
	for (i = 0; i < (muon_ptr->temperature_log_available); i++)
	{
		printf("(%f, %f)\n", muon_ptr->temperature_log_time[i], muon_ptr->temperature_log_values[i]);
	}
}
else
	printf("\nTemperature log not available\n");

/* access logged information ... events */
if (muon_ptr->events_log_available > 0)
{
	printf("\nEvent Log - Time (%s), Recorded events (%s)\n", muon_ptr->events_log_time_units, muon_ptr->events_log_values_units);
	for (i = 0; i < (muon_ptr->events_log_available); i++)
	{
		printf("(%f, %f)\n", muon_ptr->events_log_time[i], muon_ptr->events_log_values[i]);
	}
}
else
	printf("\nEvent log not available\n");

/* free memory claimed by read routine */ 
NXMfreememory(muon_ptr);
return 0;
}
