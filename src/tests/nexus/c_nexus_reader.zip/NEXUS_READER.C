/*
 * Read routine for NeXus files based on an Instrument Definition Function (IDF)
 * for ISIS Muon Time Differential instrument
 *
 *
 * Version 1
 *
 *
 * To use the read routine call:
 *
 *    int NXMread(char *nxfname, struct NXM_MUONIDF **nxfdata)
 *
 * where:
 *
 *    'nxfname' is a pointer to the NeXus filename
 *    'nxfdata' returns a pointer to a pointer to a structure containing the file information
 *
 * the value NX_OK is returned on successful read else NX_ERROR is returned
 *
 * The structure NXM_MUONIDF and function are defined in the file 'nexus_reader.h'
 *
 *
 * After use, the workspace claimed by the routine should be freed using the call:
 *
 *    void NXMfreememory(struct NXM_MUONIDF *nxfdata)
 *
 * where:
 *
 *    'nxfdata' is a pointer to the structure containing the file information
 *
 *
 * Known limitations:
 * Assumes the NXrun group contains a single NXdata group ('histogram_data_1') and
 * two NXlog groups ('temperature_log_1' and 'events_log_1')
 *
 *
 * Tested: 1) Visual C++ 5.0, Windows NT 4.0
 *
 *
 * D.W.Flannery and S.P.Cottrell
 *
 * 7-Apri-2005	Incompatibility highlighted between MuSR NeXus files and CONVERT_NEXUS files:
 *		NXM_histogram_resolution declared as INTEGER in former, as FLOAT in latter.
 *		Fixed reder to look at type and adapt accordingly.
 *		NXM_histogram_resolution is not a FLOAT.
 *
 * 15-Dec-2005  Corrected memory allocation error and made independent
 *              of HDF includes
 *              	
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "napi.h"
#include "nexus_reader.h"

#ifndef SIZE_FLOAT32
#    define SIZE_FLOAT32    4
#    define SIZE_FLOAT64    8
#    define SIZE_INT8       1
#    define SIZE_UINT8      1
#    define SIZE_INT16      2
#    define SIZE_UINT16     2
#    define SIZE_INT32      4
#    define SIZE_UINT32     4
#    define SIZE_INT64      8
#    define SIZE_UINT64     8
#    define SIZE_CHAR8      1
#    define SIZE_CHAR       1
#    define SIZE_UCHAR8     1
#    define SIZE_UCHAR      1
#    define SIZE_CHAR16     2
#    define SIZE_UCHAR16    2
#endif /* SIZE_FLOAT32 */

#ifndef VGNAMELENMAX
#define VGNAMELENMAX	    64
#endif /* VGNAMELENMAX */

#define _DEBUG_	1					/* switch for debugging information */

/* information locating read routine */
#define _READVERSION_ 1				/* Version number of read routine */
#define _IDFVERSION_ 1				/* Compatible version of Instrument Definition File */
#define _ANALYSIS_	"muonTD"		/* Compatible analysis */
#define _LAB_ "ISIS"				/* Compatible lab */



/* structure defining file information */
struct NXM_MUONIDF muon;



/* macro for adding debug information */
#define NXMdebug(format, value) \
	if (_DEBUG_) printf(format, value)



/* macro handling function calling, returns with NX_ERROR if function call failed */
#define NXMerrorhandler(function) \
	if (function != NX_OK) return NX_ERROR



static int NXMdatasize(int dataType)

/*
 * function returning size (in bytes) of NeXus data type
 */

{
	int size;
	
	switch (dataType)
	{
		case NX_CHAR:
			size = SIZE_CHAR8;
			break;
		case NX_FLOAT32:
			size = SIZE_FLOAT32;
			break;
		case NX_FLOAT64:
			size = SIZE_FLOAT64;
			break;
		case NX_INT8:
			size = SIZE_INT8;
			break;
		case NX_UINT8:
			size = SIZE_UINT8;
			break;
		case NX_INT16:
			size = SIZE_INT16;
			break;
		case NX_UINT16:
			size = SIZE_UINT16;
			break;
		case NX_INT32:
			size = SIZE_INT32;
			break;
		case NX_UINT32:
			size = SIZE_UINT32;
			break;
		default:
			size = 0;
			break;
	}

	return size;
}



static int NXMgetstringdata(NXhandle file_id, char *str)

/*
 * read a rank 1 data item of type NX_CHAR from a NeXus file
 * add a null terminator character for compatibility with C string handling
 *
 * assumes space reserved for string of length 'VGNAMELENMAX', as defined by 'NXname'
 */

{
	int i, rank, type, dims[32];
	NXname data_value;

	NXMerrorhandler((NXgetinfo(file_id, &rank, dims, &type)));
	if ((type != NX_CHAR) || (rank > 1) || (dims[0] >= VGNAMELENMAX))
	{
		printf("\nFatal error in routine 'getstringdata'\n\n");
		exit(0);
	}

	NXMerrorhandler((NXgetdata(file_id, data_value)));

	for (i = 0; i < dims[0]; i++)
		*(str + i) = *(data_value + i);
	*(str + i) = '\0';

	return 1;
}



static int NXMgetstringattr(NXhandle file_id, char *name, char *str)

/*
 * read an attribute of type NX_CHAR from a NeXus file
 * add a Null terminator character for compatibility with C string handling
 *
 * assumes space reserved for string of length 'VGNAMELENMAX', as defined by 'NXname'
 */

{
	int i, attlen, atttype;
	NXname data_value;

	attlen = VGNAMELENMAX - 1;
	atttype = NX_CHAR;
	NXMerrorhandler((NXgetattr(file_id, name, data_value, &attlen, &atttype)));

	for (i = 0; i < attlen; i++)
		*(str + i) = *(data_value + i);
	*(str + i) = '\0';

	return 1;
}



static void *NXMmemoryhandler(NXhandle file_id)

/*
 * allocate memory for a NeXus data item, calls NXgetinfo to determine size
 *
 * function returns a pointer to memory block
 */

{
	int i, rank, type, dims[32], size;
	char *data_ptr;

	NXMerrorhandler((NXgetinfo(file_id, &rank, dims, &type)));
	size = dims[0];
	for (i = 1; i < rank; i++)
		size = size * dims[i];
	size = size * NXMdatasize(type);
	if ((data_ptr = malloc (size)) == NULL)
		{
		printf("\nMemory allocation error: can't allocate %d bytes\n\n", size);
		exit(0);
		}
        return data_ptr;
}



static void NXMfree(void *data_ptr)

/*
 *
 * free memory from NeXus data items provided pointer argument is non NULL
 *
 */

{
	if (data_ptr != NULL) free(data_ptr);
}



int NXMread(char *nxfname, struct NXM_MUONIDF **nxfdata)

/*
 * return data from NeXus file 'nxfname' in structure 'nxfdata'
 *
 * function returns NX_OK on success, otherwise NX_ERROR
 */

{
	NXhandle file_id;
	NXname group_name, class_name, data_name;
	int i, attlen, atttype, numitems, data_type, uif_count;
	int xrank, xdim, xtype, i_hist_res, r_hist_res;

	*nxfdata = &muon;

	/* open NeXus file for reading */
	NXMerrorhandler((NXopen(nxfname, NXACC_READ, &file_id)));
	NXMdebug("%s\n", "Opening NeXus file...");

	/* open root group 'NXentry' */
    NXMerrorhandler((NXopengroup(file_id, "run", "NXentry")));
	NXMdebug("%s\n", "Opening 'NXentry'...");

	/* display (in debug mode) NeXus reader version and IDF compatible version number */
	NXMdebug("\nNeXus reader version %d\n", _READVERSION_);
	NXMdebug("Compatible with Instrument Definition File version %d\n\n", _IDFVERSION_);

	/* read IDF version */
	NXMerrorhandler((NXopendata(file_id, "IDF_version")));
	NXMerrorhandler((NXgetdata(file_id, &muon.run_IDF_version)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("IDF version: %d\n", muon.run_IDF_version);

	/* read 'analysis' */
	NXMerrorhandler((NXopendata(file_id, "analysis")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.run_analysis)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Analysis: %s\n", muon.run_analysis);

	/* read 'lab' */
	NXMerrorhandler((NXopendata(file_id, "lab")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.run_lab)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Lab: %s\n", muon.run_lab);

	/* check reader compatibility */
	if ((muon.run_IDF_version != _IDFVERSION_) || (strcmp(muon.run_analysis, _ANALYSIS_)) || (strcmp(muon.run_lab, _LAB_)))
	{
		printf("\nFatal error: Read routine incompatible with Instrument Definition used to write data\n");
		printf("Found, IDF Version: %d, Analysis: %s, Lab: %s\n", muon.run_IDF_version, muon.run_analysis, muon.run_lab);
		printf("Expecting: IDF Version: %d, Analysis: %s, Lab: %s\n\n", _IDFVERSION_, _ANALYSIS_, _LAB_);
		exit(0);
	}

	/* read 'beamline' */
	NXMerrorhandler((NXopendata(file_id, "beamline")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.run_beamline)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Beamline: %s\n", muon.run_beamline);

	/* read 'program_name' and 'program_version' */
    NXMerrorhandler((NXopendata(file_id, "program_name")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.run_program_name)));
	NXMerrorhandler((NXMgetstringattr(file_id, "version", muon.run_program_version)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Program name: %s\n", muon.run_program_name);
	NXMdebug("Program version: %s\n", muon.run_program_version);

	/* read 'number' */
	NXMerrorhandler((NXopendata(file_id, "number")));
	NXMerrorhandler((NXgetdata(file_id, &muon.run_number)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Run number: %d\n", muon.run_number);

	/* read 'title' */
	NXMerrorhandler((NXopendata(file_id, "title")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.run_title)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Title: %s\n", muon.run_title);

	/* read 'notes' */
	NXMerrorhandler((NXopendata(file_id, "notes")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.run_notes)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Notes: %s\n", muon.run_notes);

	/* read 'start_time' */
	NXMerrorhandler((NXopendata(file_id, "start_time")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.run_start_time)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Start time: %s\n", muon.run_start_time);

	/* read 'stop_time' */
	NXMerrorhandler((NXopendata(file_id, "stop_time")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.run_stop_time)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Stop time: %s\n", muon.run_stop_time);

	/* read 'duration' */
	NXMerrorhandler((NXopendata(file_id, "duration")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.run_duration)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Duration: %s\n", muon.run_duration);

	/* read 'switching_states' (rgmode) */
	NXMerrorhandler((NXopendata(file_id, "switching_states")));
	NXMerrorhandler((NXgetdata(file_id, &muon.run_switching_states)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Switching States: %d\n", muon.run_switching_states);
       
	/* open subgroup 'NXuser' */
	NXMerrorhandler((NXopengroup(file_id, "user", "NXuser")));
    NXMdebug("%s\n", "Opening 'NXuser'...");

	/* read user information - two fixed entries and the information from the UIF file */
	NXMerrorhandler((NXinitgroupdir(file_id)));
	NXMerrorhandler((NXgetgroupinfo(file_id, &numitems, group_name, class_name)));
	NXMdebug("Group Info: %s", class_name);
	NXMdebug(", %s", group_name);
	NXMdebug(", %d\n", numitems);
	if ((numitems - 2) > 0)
	{
		if ((muon.user_uif_array = (struct NXM_MUONUIF *) malloc((numitems - 2) * sizeof(struct NXM_MUONUIF))) == NULL)
		{
			printf("\nUnable to allocate memory for User Information array\n\n");
			exit(0);
		}
	}
	else
	{
		muon.user_uif_array = (struct NXM_MUONUIF *) NULL;
	}
	uif_count = 0;
	for (i = 0; i < numitems; i++)
	{
		NXMerrorhandler((NXgetnextentry(file_id, data_name, class_name, &data_type)));
		NXMerrorhandler((NXopendata(file_id, data_name)));
		NXMdebug("Data name: %s\n", data_name);
		if (strcmp(data_name, "name") == 0)
		{
			NXMerrorhandler((NXMgetstringdata(file_id, muon.user_name)));
			NXMdebug("User name: %s\n", muon.user_name);
		}
		else if (strncmp(data_name, "experiment_number", 2) == 0)
		{
			NXMerrorhandler((NXMgetstringdata(file_id, muon.user_experiment_number)));
			NXMdebug("Experiment number: %s\n", muon.user_experiment_number);
		}
		else
		{
			NXMerrorhandler((NXMgetstringdata(file_id, (char *) muon.user_uif_array[uif_count].uif_element_value)));
			strcpy((char *) muon.user_uif_array[uif_count].uif_element_name, (char *) data_name);
			NXMdebug("Data value %d: ", uif_count);
			NXMdebug("%s\n", muon.user_uif_array[uif_count].uif_element_value);
			uif_count++;
		}
		NXMerrorhandler((NXclosedata(file_id)));
	}
	muon.user_uif_array_length = uif_count;
	NXMdebug("UIF array length: %d\n", muon.user_uif_array_length);

	/* close subgroup 'NXuser' */
	NXMerrorhandler((NXclosegroup(file_id)));
	NXMdebug("%s\n", "Close 'NXuser'");

	/* open subgroup 'NXsample' */
	NXMerrorhandler((NXopengroup(file_id, "sample", "NXSample")));
	NXMdebug("%s\n", "Opening 'NXsample'...");

	/* read 'name' */
	NXMerrorhandler((NXopendata(file_id, "name")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.sample_name)));
	NXMerrorhandler((NXclosedata(file_id)));
    NXMdebug("Sample name: %s\n", muon.sample_name);
		
	/* read 'temperature' */
	NXMerrorhandler((NXopendata(file_id, "temperature")));
	NXMerrorhandler((NXgetdata(file_id, &muon.sample_temperature)));
	NXMerrorhandler((NXMgetstringattr(file_id, "units", muon.sample_temperature_units)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Temperature label: %f\n", muon.sample_temperature);
	NXMdebug("Temperature units: %s\n", muon.sample_temperature_units);

	/* read 'magnetic_field' */
	NXMerrorhandler((NXopendata(file_id, "magnetic_field")));
	NXMerrorhandler((NXgetdata(file_id, &muon.sample_magnetic_field)));
	NXMerrorhandler((NXMgetstringattr(file_id, "units", muon.sample_magnetic_field_units)));
	NXMerrorhandler((NXclosedata(file_id)));
    NXMdebug("Magnetic field: %f\n", muon.sample_magnetic_field);
	NXMdebug("Field units: %s\n", muon.sample_magnetic_field_units);

	/* read 'shape' */
	NXMerrorhandler((NXopendata(file_id, "shape")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.sample_shape)));
	NXMerrorhandler((NXclosedata(file_id)));  
    NXMdebug("Shape: %s\n", muon.sample_shape);

	/* read 'magnetic_field_state' */
	NXMerrorhandler((NXopendata(file_id, "magnetic_field_state")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.sample_magnetic_field_state)));
	NXMerrorhandler((NXclosedata(file_id)));  
    NXMdebug("Magnetic field state: %s\n", muon.sample_magnetic_field_state);

	/* read 'magnetic_field_vector' and 'coordinate_system' attribute */
	NXMerrorhandler((NXopendata(file_id, "magnetic_field_vector")));
	attlen = SIZE_INT32;
	atttype = NX_INT32;
	NXMerrorhandler((NXgetattr(file_id, "available", &muon.sample_magnetic_field_vector_available, &attlen, &atttype)));
	if (muon.sample_magnetic_field_vector_available != 0)
	{
		muon.sample_magnetic_field_vector = (float *) NXMmemoryhandler(file_id);
		NXMerrorhandler((NXgetdata(file_id, muon.sample_magnetic_field_vector)));
		NXMdebug("Magnetic field vector: [%f, ", muon.sample_magnetic_field_vector[0]);
		NXMdebug("%f, ", muon.sample_magnetic_field_vector[1]);
		NXMdebug("%f]\n", muon.sample_magnetic_field_vector[2]);
		NXMerrorhandler((NXMgetstringattr(file_id, "coordinate_system", muon.sample_magnetic_field_vector_coord)));
		NXMdebug("Coordinate system: %s\n", muon.sample_magnetic_field_vector_coord);
	}
	else
	{
		muon.sample_magnetic_field_vector = (float *) NULL;
		NXMdebug("%s\n", "Magnetic field vector not available\n");
	}
	NXMerrorhandler((NXclosedata(file_id)));

	/* read 'environment' */
	NXMerrorhandler((NXopendata(file_id, "environment")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.sample_environment)));
	NXMerrorhandler((NXclosedata(file_id)));  
    NXMdebug("Sample environment: %s\n", muon.sample_environment);

	/* close subgroup 'NXsample' */
	NXMerrorhandler((NXclosegroup(file_id)));
    NXMdebug("%s\n", "Close 'NXsample'");

	/* open subgroup 'NXinstrument' */
	NXMerrorhandler((NXopengroup(file_id, "instrument", "NXinstrument")));
	NXMdebug("%s\n", "Open 'NXinstrument'...");

	/* read 'name' */
	NXMerrorhandler((NXopendata(file_id, "name")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.instrument_name)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Instrument name: %s\n", muon.instrument_name);

	/* open subgroup 'NXdetector' */
	NXMerrorhandler((NXopengroup(file_id, "detector", "NXdetector")));
    NXMdebug("%s\n", "Open 'NXdetector'...");

	/* read 'number' */
	NXMerrorhandler((NXopendata(file_id, "number")));
	NXMerrorhandler((NXgetdata(file_id, &muon.detector_number)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Number of detectors: %d\n", muon.detector_number);

	/* read 'orientation' */
	NXMerrorhandler((NXopendata(file_id, "orientation")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.detector_orientation)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Orientation of detectors: %s\n", muon.detector_orientation);

	/* read 'angles' and 'coordinate_system' attribute */
	NXMerrorhandler((NXopendata(file_id, "angles")));
	attlen = SIZE_INT32;
	atttype = NX_INT32;
	NXMerrorhandler((NXgetattr(file_id, "available", &muon.detector_angles_available, &attlen, &atttype)));
	if (muon.detector_angles_available != 0)
	{
		muon.detector_angles = (float *) NXMmemoryhandler(file_id);
		NXMerrorhandler((NXgetdata(file_id, muon.detector_angles)));
		NXMdebug("%s\n", "Reading detector angles");
		NXMerrorhandler((NXMgetstringattr(file_id, "coordinate_system", muon.detector_angles_coord)));
		NXMdebug("Coordinate system: %s\n", muon.detector_angles_coord);
	}
	else
	{
		muon.detector_angles = (float *) NULL;
		NXMdebug("%s\n", "not available");
	}
	NXMerrorhandler((NXclosedata(file_id)));

	/* read 'available' attribute and, if necessary, the 'deadtimes' and 'units' */
	NXMerrorhandler((NXopendata(file_id, "deadtimes")));
	NXMdebug("%s", "Reading detector deadtimes ... ");
	attlen = SIZE_INT32;
	atttype = NX_INT32;
	NXMerrorhandler((NXgetattr(file_id, "available", &muon.detector_deadtimes_available, &attlen, &atttype)));
	if (muon.detector_deadtimes_available > 0)
	{
		muon.detector_deadtimes = (float *) NXMmemoryhandler(file_id);
		NXMerrorhandler((NXgetdata(file_id, muon.detector_deadtimes)));
		NXMerrorhandler((NXMgetstringattr(file_id, "units", muon.detector_deadtimes_units)));
		NXMdebug("%s\n", "available");
	}
	else
	{
		muon.detector_deadtimes = (float *) NULL;
		NXMdebug("%s\n", "not available");
	}

	/* close subgroup 'NXdetector' */
	NXMerrorhandler((NXclosegroup(file_id)));
	NXMdebug("%s\n", "Close 'NXinstrument'");

	/* open subgroup 'NXcollimator' */
	NXMerrorhandler((NXopengroup(file_id, "collimator", "NXcollimator")));
	NXMdebug("%s\n", "Open 'NXcollimator'...");

	/* read 'type' */
	NXMerrorhandler((NXopendata(file_id, "type")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.collimator_type)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Orientation of detectors: %s\n", muon.collimator_type);

	/* read 'aperture' */
	NXMerrorhandler((NXopendata(file_id, "aperture")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.collimator_aperture)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Orientation of detectors: %s\n", muon.collimator_aperture);

	/* close subgroup 'NXcollimator' */
	NXMerrorhandler((NXclosegroup(file_id)));
	NXMdebug("%s\n", "Close 'NXcollimator'");

	/* open subgroup 'NXbeam' */
	NXMerrorhandler((NXopengroup(file_id, "beam", "NXbeam")));
	NXMdebug("%s\n", "Open 'NXbeam'...");

	/* read 'total_counts' */
	NXMerrorhandler((NXopendata(file_id, "total_counts")));
	NXMerrorhandler((NXgetdata(file_id, &muon.beam_total_counts)));
	NXMerrorhandler((NXMgetstringattr(file_id, "units", muon.beam_total_counts_units)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Total counts: %f\n", muon.beam_total_counts);
	NXMdebug("Units: %s\n", muon.beam_total_counts_units);

	/* read 'daereads' */
	NXMerrorhandler((NXopendata(file_id, "daereads")));
	NXMerrorhandler((NXgetdata(file_id, &muon.beam_daereads)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("DAE Reads: %d\n", muon.beam_daereads);

	/* read 'frames' */
	NXMerrorhandler((NXopendata(file_id, "frames")));
	NXMerrorhandler((NXgetdata(file_id, &muon.beam_frames)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Frames: %d\n", muon.beam_frames);

	/* close subgroup 'NXbeam' */
	NXMerrorhandler((NXclosegroup(file_id)));
	NXMdebug("%s\n", "Close 'NXbeam'");

	/* close subgroup 'NXdetector' */
	NXMerrorhandler((NXclosegroup(file_id)));
	NXMdebug("%s\n", "Close 'NXdetector'");
    
	/* open subgroup 'NXdata' */
	NXMerrorhandler((NXopengroup(file_id, "histogram_data_1", "NXdata")));
	NXMdebug("%s\n", "Open 'NXdata'...");

	/* read 'counts' */
	NXMerrorhandler((NXopendata(file_id, "counts")));
	muon.histogram_counts = (int *) NXMmemoryhandler(file_id);
	NXMerrorhandler((NXgetdata(file_id, muon.histogram_counts)));
	/* read 'counts' attributes */
	attlen = SIZE_INT32;
	atttype = NX_INT32;
	NXMerrorhandler((NXgetattr(file_id, "number", &muon.histogram_number, &attlen, &atttype)));
	NXMerrorhandler((NXgetattr(file_id, "length", &muon.histogram_length, &attlen, &atttype)));
	NXMerrorhandler((NXgetattr(file_id, "t0_bin", &muon.histogram_t0_bin, &attlen, &atttype)));
	NXMerrorhandler((NXgetattr(file_id, "first_good_bin", &muon.histogram_first_good_bin, &attlen, &atttype)));
	NXMerrorhandler((NXgetattr(file_id, "last_good_bin", &muon.histogram_last_good_bin, &attlen, &atttype)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("%s\n", "Read histogram data");

	/* read 'histogram_resolution' */
	NXMerrorhandler((NXopendata(file_id, "resolution")));
	NXMerrorhandler((NXgetinfo(file_id, &xrank, &xdim, &xtype)));
	if (xtype == NX_INT32)
		{
		NXMerrorhandler((NXgetdata(file_id, &i_hist_res)));
		muon.histogram_resolution = (float)i_hist_res;
		}
	else if (xtype == NX_FLOAT32)
		{
		NXMerrorhandler((NXgetdata(file_id, &r_hist_res)));
		muon.histogram_resolution = r_hist_res;
		}
	NXMerrorhandler((NXMgetstringattr(file_id, "units", muon.histogram_resolution_units)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Histogram resolution: %f\n", muon.histogram_resolution);
	NXMdebug("Units: %s\n", muon.histogram_resolution_units);

	/* read 'raw_time' */
	NXMerrorhandler((NXopendata(file_id, "raw_time")));
	muon.histogram_raw_time = (float *) NXMmemoryhandler(file_id);
	NXMerrorhandler((NXgetdata(file_id, muon.histogram_raw_time)));
	/* read 'raw_time' attributes */
	NXMerrorhandler((NXMgetstringattr(file_id, "units", muon.histogram_raw_time_units)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("%s\n", "Read Raw Time");
	NXMdebug("Units: %s\n", muon.histogram_raw_time_units);

	/* read 'corrected_time' */
	NXMerrorhandler((NXopendata(file_id, "corrected_time")));
	muon.histogram_corrected_time = (float *) NXMmemoryhandler(file_id);
	NXMerrorhandler((NXgetdata(file_id, muon.histogram_corrected_time)));
	/* read 'corrected_time' attributes */
	NXMerrorhandler((NXMgetstringattr(file_id, "units", muon.histogram_corrected_time_units)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("%s\n", "Read Corrected Time");
	NXMdebug("Units: %s\n", muon.histogram_corrected_time_units);

	/* read 'grouping' if attribute 'available' is non-zero */
	NXMerrorhandler((NXopendata(file_id, "grouping")));
	NXMdebug("%s", "Reading Histogram grouping ... ");
	attlen = SIZE_INT32;
	atttype = NX_INT32;
	NXMerrorhandler((NXgetattr(file_id, "available", &muon.histogram_grouping_available, &attlen, &atttype)));
	if (muon.histogram_grouping_available > 0)
	{
		NXMdebug("%d groups found\n", muon.histogram_grouping_available);
		muon.histogram_grouping = (int *) NXMmemoryhandler(file_id);
		NXMerrorhandler((NXgetdata(file_id, muon.histogram_grouping)));
	}
	else
	{
		muon.histogram_grouping = (int *) NULL;
		NXMdebug("%s\n", "no grouping data found");
	}

	/* read 'alpha' if attribute 'available' is non-zero */
	NXMerrorhandler((NXopendata(file_id, "alpha")));
	NXMdebug("%s", "Reading alpha for grouped pairs ... ");
	attlen = SIZE_INT32;
	atttype = NX_INT32;
	NXMerrorhandler((NXgetattr(file_id, "available", &muon.histogram_alpha_available, &attlen, &atttype)));
	if (muon.histogram_alpha_available > 0)
	{
		NXMdebug("%d alpha pairs found\n", muon.histogram_alpha_available);
		muon.histogram_alpha = (float *) NXMmemoryhandler(file_id);
		NXMerrorhandler((NXgetdata(file_id, muon.histogram_alpha)));
	}
	else
	{	
		muon.histogram_alpha = (float *) NULL;
		NXMdebug("%s\n", "no alpha pairs found");
	}

	/* close subgroup 'NXdata' */
	NXMerrorhandler((NXclosegroup(file_id)));
	NXMdebug("%s\n", "Close 'NXdata'");

	/* open subgroup 'NXlog' (temperature) */
	NXMerrorhandler((NXopengroup(file_id, "temperature_log_1", "NXlog")));
	NXMdebug("%s\n", "Open 'NXlog' (temperature)...");

	/* read 'temperature name' and the 'available' attribute */
	NXMerrorhandler((NXopendata(file_id, "name")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.temperature_log_name)));
	attlen = SIZE_INT32;
	atttype = NX_INT32;
	NXMerrorhandler((NXgetattr(file_id, "available", &muon.temperature_log_available, &attlen, &atttype)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Logged name: %s, ", muon.temperature_log_name);
	NXMdebug("%d values available\n", muon.temperature_log_available);

	/* if 'available' then read ... */
	if (muon.temperature_log_available > 0)
	{
		/* 'temperature values' and 'length' and 'units' attributes */
		NXMerrorhandler((NXopendata(file_id, "values")));           
		muon.temperature_log_values = (float *) NXMmemoryhandler(file_id);
		NXMerrorhandler((NXgetdata(file_id, muon.temperature_log_values)));
		NXMerrorhandler((NXMgetstringattr(file_id, "units", muon.temperature_log_values_units)));
 		NXMerrorhandler((NXclosedata(file_id)));
		NXMdebug("First temperature value logged: %f\n", muon.temperature_log_values[0]);

		/* 'temperature time' and 'units' attribute */
		NXMerrorhandler((NXopendata(file_id, "time")));
		muon.temperature_log_time = (float *) NXMmemoryhandler(file_id);
		NXMerrorhandler((NXgetdata(file_id, muon.temperature_log_time)));
		NXMerrorhandler((NXMgetstringattr(file_id, "units", muon.temperature_log_time_units)));
		NXMerrorhandler((NXclosedata(file_id)));  
		NXMdebug("%s\n", "Read time data");
		NXMdebug("Logging started at time %f\n", muon.temperature_log_time[0]);
	}
	else
	{
		muon.temperature_log_values = (float *) NULL;
		muon.temperature_log_time = (float *) NULL;
	}

	/* close subgroup 'NXlog' (temperature) */
	NXMerrorhandler((NXclosegroup(file_id)));
	NXMdebug("%s\n", "Close 'NXlog' (temperature)");

	/* open subgroup 'NXlog' (events) */
	NXMerrorhandler((NXopengroup(file_id, "event_log_1", "NXlog")));
	NXMdebug("%s\n", "Open 'NXlog' (events)...");

	/* read 'events name' */
	NXMerrorhandler((NXopendata(file_id, "name")));
	NXMerrorhandler((NXMgetstringdata(file_id, muon.events_log_name)));
	attlen = SIZE_INT32;
	atttype = NX_INT32;
	NXMerrorhandler((NXgetattr(file_id, "available", &muon.events_log_available, &attlen, &atttype)));
	NXMerrorhandler((NXclosedata(file_id)));
	NXMdebug("Logged name: %s, ", muon.events_log_name);
	NXMdebug("%d values available\n", muon.events_log_available);

	/* if 'available' then read ... */
	if (muon.events_log_available > 0)
	{
		/* 'events values' and 'units' attributes */
		NXMerrorhandler((NXopendata(file_id, "values")));           
		muon.events_log_values = (float *) NXMmemoryhandler(file_id);
		NXMerrorhandler((NXgetdata(file_id, muon.events_log_values)));
		NXMerrorhandler((NXMgetstringattr(file_id, "units", muon.events_log_values_units)));
		NXMerrorhandler((NXclosedata(file_id)));  
		NXMdebug("First events value logged: %f\n", muon.events_log_values[0]);

		/* read 'events time' and 'units' attribute */
		NXMerrorhandler((NXopendata(file_id, "time")));
		muon.events_log_time = (float *) NXMmemoryhandler(file_id);
		NXMerrorhandler((NXgetdata(file_id, muon.events_log_time)));            
		NXMerrorhandler((NXMgetstringattr(file_id, "units", muon.events_log_time_units)));
		NXMerrorhandler((NXclosedata(file_id)));
		NXMdebug("%s\n", "Read time data");
		NXMdebug("Logging started at time %f\n", muon.events_log_time[0]);
	}
	else
	{
		muon.events_log_values = (float *) NULL;
		muon.events_log_time = (float *) NULL;
	}

	/* close subgroup 'NXlog' (events) */
	NXMerrorhandler((NXclosegroup(file_id)));
	NXMdebug("%s\n", "Close 'NXlog' (events)");

	/* close root group 'NXentry' */
    NXMerrorhandler((NXclosegroup(file_id)));
	NXMdebug("%s\n", "Close 'NXentry'");

    /* close NeXus file */
	NXMerrorhandler((NXclose (&file_id)));
	NXMdebug("%s\n", "Close NeXus file");

	return NX_OK;
}



/* NXMfreememory - free memory claimed in NeXus file */

void NXMfreememory(struct NXM_MUONIDF *nxfdata)

{
	/* NXlog (temperature) */
	NXMfree(nxfdata->temperature_log_values);
    NXMfree(nxfdata->temperature_log_time);
	/* NXlog (events) */
	NXMfree(nxfdata->events_log_values);
    NXMfree(nxfdata->events_log_time);
	/* NXdata */
    NXMfree(nxfdata->histogram_counts);
	NXMfree(nxfdata->histogram_raw_time);
	NXMfree(nxfdata->histogram_corrected_time);
	NXMfree(nxfdata->histogram_grouping);
	NXMfree(nxfdata->histogram_alpha);
	/* NXuser */
	NXMfree(nxfdata->user_uif_array);
	/* NXsample */
	NXMfree(nxfdata->sample_magnetic_field_vector);
	/* NXdetector */
	NXMfree(nxfdata->detector_angles);
	NXMfree(nxfdata->detector_deadtimes);
}
